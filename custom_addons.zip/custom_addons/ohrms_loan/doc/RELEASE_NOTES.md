## Module <ohrms_loan>

#### 01.10.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Open HRMS Loan Management
