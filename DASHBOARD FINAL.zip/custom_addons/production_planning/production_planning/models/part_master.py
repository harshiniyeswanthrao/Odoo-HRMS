from odoo import models, fields

class PartMaster(models.Model):
    _name = 'part.master'
    _description = 'Part Master'

    name = fields.Char('Part Name', required=True)
    description = fields.Text('Description')
    item_code = fields.Char('Item Code', required=True)  # Updated from Many2one to Char
    part_number = fields.Char('Part Number')
    price_per_piece = fields.Float('Price/Piece', required=True)  # New field
    quality = fields.Char('Quality')  # New field
    size = fields.Char('Size')  # New field
