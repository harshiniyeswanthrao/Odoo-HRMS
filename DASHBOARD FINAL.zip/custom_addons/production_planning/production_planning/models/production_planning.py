from odoo import models, fields

class ProductionPlanning(models.Model):
    _name = 'production.planning'
    _description = 'Production Planning'

    name = fields.Char('Planning Name', required=True)
    production_cell_id = fields.Many2one('production.cell.master', string='Production Cell', required=True)
    machine_id = fields.Many2one('machine.master', string='Machine', required=True)
    part_lines = fields.One2many('production.planning.line', 'planning_id', string='Part Lines')
    planned_start_date = fields.Datetime('Planned Start Date')
    planned_end_date = fields.Datetime('Planned End Date')

