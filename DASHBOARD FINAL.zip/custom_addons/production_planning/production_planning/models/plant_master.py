from odoo import models, fields

class PlantMaster(models.Model):
    _name = 'plant.master'
    _description = 'Plant Master'

    name = fields.Char(string="Plant Name", required=True)
    location = fields.Char(string="Location")
    production_cells = fields.One2many(
        'production.cell.master', 'plant_id', string="Production Cells"
    )
