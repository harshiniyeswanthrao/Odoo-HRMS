from odoo import models, fields

class ProductionCellMaster(models.Model):
    _name = 'production.cell.master'
    _description = 'Production Cell Master'

    name = fields.Char('Production Cell Name', required=True)
    description = fields.Text('Description')
    location = fields.Char('Location')


class ProductionCellMasterInherit(models.Model):
    _inherit = 'production.cell.master'

    plant_id = fields.Many2one('plant.master', string="Plant", required=True)

