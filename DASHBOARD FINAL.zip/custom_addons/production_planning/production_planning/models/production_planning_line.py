from odoo import models, fields

class ProductionPlanningLine(models.Model):
    _name = 'production.planning.line'
    _description = 'Production Planning Line'

    planning_id = fields.Many2one('production.planning', string='Production Planning')
    part_master_id = fields.Many2one('part.master', string='Part', required=True)
    quantity = fields.Float('Quantity', required=True)
