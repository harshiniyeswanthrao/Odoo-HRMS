{
    'name': 'Production Planning',
    'version': '1.0',
    'summary': 'Custom module for Production Planning',
    'description': 'This module helps with the planning of production processes by selecting machine, parts, and production cell.',
    'author': 'Your Name',
    'category': 'Manufacturing',
    'depends': ['base', 'product'],
    'data': [
        'security/ir.model.access.csv',
        'views/production_planning_views.xml',
        'views/actions.xml',
        'views/menu.xml',
    ],
    'installable': True,
    'application': True,
}
