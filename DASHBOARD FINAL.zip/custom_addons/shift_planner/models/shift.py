from odoo import models, fields, api
from datetime import datetime, timedelta

class ShiftPlanner(models.Model):
    _name = 'shift.planner'
    _description = 'Shift Planner'
    _inherit = ['mail.thread','mail.activity.mixin']


    # Shift name with dropdown options
    name = fields.Selection(
        string="Shift Name",
        selection=[('general', 'General Shift'),
                   ('morning', '6 am - 2 pm '),
                   ('afternoon', '2 pm - 10 pm '),
                   ('evening', '10 pm - 6 am')],
        required=True, tracking = True,
        default='general',  # Default option if no value is selected
    )
    # Shift type (e.g., Regular, Overtime)
    shift_type = fields.Selection(
        [('regular', 'Regular'), ('overtime', 'Overtime')],
        string="Shift Type",
        required=True,tracking = True,
        default='regular'
    )

    # Start time of the shift
    start_datetime = fields.Datetime(string="Start Time", required=True, tracking = True,)

    # End time of the shift
    end_datetime = fields.Datetime(string="End Time", required=True,tracking = True,)

    # Employees linked to the shift (Many2many field for multiple employees)
    employee_ids = fields.Many2many('hr.employee', string="Employees")

    # Optional notes or descriptions
    notes = fields.Text(string="Notes")

    # Compute the total working hours of the shift
    working_hours = fields.Float(
        string="Working Hours",
        compute='_compute_working_hours',
        store=True,
    )

    @api.depends('start_datetime', 'end_datetime')
    def _compute_working_hours(self):
        for record in self:
            if record.start_datetime and record.end_datetime:
                # Calculate the difference in hours between start and end times
                delta = record.end_datetime - record.start_datetime
                # Convert timedelta to hours
                record.working_hours = delta.total_seconds() / 3600
            else:
                record.working_hours = 0

    # @api.model
    # def create(self, vals):
    #     """Automatically update employee records with shift details when a new shift planner is created."""
    #     res = super(ShiftPlanner, self).create(vals)
    #     res._update_employee_shifts()
    #     return res
    #
    # def write(self, vals):
    #     """Automatically update employee records with shift details when the shift planner is updated."""
    #     res = super(ShiftPlanner, self).write(vals)
    #     self._update_employee_shifts()
    #     return res
    #
    # def _update_employee_shifts(self):
    #     """Ensure this shift is assigned to all selected employees."""
    #     for record in self:
    #         if record.employee_id:
    #             for employee in record.employee_id:
    #                 # Correctly update the Many2many field 'shift_ids'
    #                 employee.shift_ids = [(4, record.id)]
