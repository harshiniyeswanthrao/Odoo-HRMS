from odoo import models, fields

class Employee(models.Model):
    _inherit = 'hr.employee'


    # Many2many field to link an employee to multiple shifts
    shift_ids = fields.Many2many(
        'shift.planner',
        string="Shifts",
        help="Shifts assigned to the employee."
    )