document.addEventListener('DOMContentLoaded', function () {
    console.log('Auction User scripts loaded.');
});